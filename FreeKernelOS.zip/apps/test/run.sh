#!/bin/sh

ROOT="$(cd "$(dirname "$0")" && pwd)"
CUR="$ROOT"

while true; do
    clear
    echo "=== FILE MANAGER ==="
    echo "Dir: $CUR"
    echo "---------------------"
    ls "$CUR"
    echo "---------------------"
    echo "Commands:"
    echo " open <name> | back | new <name> | del <name> | exit"
    printf "> "
    read CMD ARG

    case "$CMD" in
        open)
            if [ -d "$CUR/$ARG" ]; then
                CUR="$CUR/$ARG"
            elif [ -f "$CUR/$ARG" ]; then
                echo "--- FILE CONTENT ---"
                cat "$CUR/$ARG" 2>/dev/null || echo "(binary or empty)"
                read -p "(press enter)" X
            else
                echo "not found"
                sleep 0.5
            fi
            ;;
        back)
            if [ "$CUR" != "$ROOT" ]; then
                CUR=$(dirname "$CUR")
            fi
            ;;
        new)
            mkdir -p "$CUR/$ARG"
            ;;
        del)
            rm -rf "$CUR/$ARG"
            ;;
        exit)
            break
            ;;
        *)
            echo "unknown command"
            sleep 0.5
            ;;
    esac
done
