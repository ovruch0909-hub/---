#!/bin/sh

FLAG="../../kernel_system/root.flag"

if [ ! -f "$FLAG" ]; then
    echo "[RootShell] Permission denied (root not installed)"
    exit 1
fi

echo "[RootShell] Root shell started"

while true; do
    printf "root> "
    read CMD ARG

    case "$CMD" in
        ls)
            ls "$ARG"
            ;;
        cat)
            cat "$ARG"
            ;;
        exit)
            echo "[RootShell] exit"
            break
            ;;
        *)
            echo "[RootShell] Unknown cmd '$CMD'"
            ;;
    esac
done
