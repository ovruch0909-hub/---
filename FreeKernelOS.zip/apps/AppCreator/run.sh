#!/bin/sh

BUILDER="../../system/appbuilder"
APPDIR="../../apps"

echo "[Creator] App name:"
read NAME

mkdir -p "$APPDIR/$NAME/bin"

echo "[Creator] App code:"
read CODE

# пакет формата
cat > "$APPDIR/$NAME/app.akk.kert" << EOF2
APP=$NAME
MAIN=run.sh
EOF2

# бинарь (условный)
echo "$CODE" > "$APPDIR/$NAME/bin/core.bin"

# рантайм
cat > "$APPDIR/$NAME/run.sh" << EOF3
#!/bin/sh
echo "[APP:$NAME] $CODE"
EOF3

chmod +x "$APPDIR/$NAME/run.sh"

# ярлык
touch "$APPDIR/$NAME/icon.lnk"

# рефреш desktop
sh "$BUILDER/Desktop.rld"

echo "[Creator] App '$NAME' installed!"
