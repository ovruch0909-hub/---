#!/bin/sh
echo "[APP:HelloWorld] Hello World!"
