#!/bin/sh
echo "[Installer] Installing root tools..."
mkdir -p ../../kernel_system
echo "ROOT=1" > ../../kernel_system/root.flag
echo "[Installer] Root enabled!"
