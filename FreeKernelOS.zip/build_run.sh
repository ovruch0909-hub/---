#!/bin/sh

APP=$1

if [ -z "$APP" ]; then
    echo "[ERROR] Usage: sh build_run.sh APPNAME"
    exit 1
fi

echo "[1] BUILDING $APP.akk"
mkdir -p build/$APP

cat > build/$APP/format.akk <<EOF
APP_NAME=$APP
APP_MAIN=run.sh
EOF

cat > build/$APP/run.sh <<EOF
#!/bin/sh
echo "[APP:$APP] Hello World!"
EOF

chmod +x build/$APP/run.sh
echo "[OK] Builder done"

echo "[2] INSTALLING"
mkdir -p apps/$APP
cp build/$APP/* apps/$APP/
echo "[OK] Installed"

echo "[3] RUNNING SYSTEM"
cd system/runtime

# фикс чтобы kernel запускался
chmod +x ../../kernel/kernel.kerm 2>/dev/null

sh init.daemon &

sleep 0.3

echo "[4] RUNNING APP"
cd ../../apps/$APP
sh run.sh
